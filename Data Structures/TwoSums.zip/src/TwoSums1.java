import java.util.*;
public class TwoSums1 {
	public static int[] ans(int[] nums, int target) {
		Map<Integer, Integer> ht = new HashMap<>();
		int a[]=new int[2];
        for(int i=0;i<nums.length;i++) {
			int value=target-nums[i];
			if(ht.containsValue(i)) {
				a[0]=value;
                a[1]=ht.get(i);
            }
			else {
				ht.put(i, value);
			}
		}
        return a;
	}
	

public static void main(String[] args ) {
	int arr[]= {2,7,11,15};
	int t=9;
	System.out.println(ans(arr,t));
}
}
